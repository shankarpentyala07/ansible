## Machine Preparation and ICP4D Installation:

-  Make sure ansible is installed on your machine from where you are
    running ansible scripts.

- Reference Link to Install Ansible: <https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html>

- Clone the <git@github.ibm.com:PrivateCloud-analytics/ClientExperience.git> repository

- Navigate to ansible directory

- Edit the hosts file with your machine public/Private IP's and login credentials.

- Below is the sample hots file for 3 node cluster with 1 load balancer

```
[cluster]
9.**.***.**  private_ip=***.**.***.**    name=master1  type=worker ansible_ssh_user=****  ansible_ssh_pass=*****
9.**.***.**  private_ip=***.**.***.**    name=master2  type=worker ansible_ssh_user=****  ansible_ssh_pass=*****
9.**.***.*** private_ip=***.**.***.**    name=master3  type=worker ansible_ssh_user=****  ansible_ssh_pass=*****

[loadbalancer]
 9.**.***.*** private_ip=***.**.***.**  name=loadbalancer type=proxy ansible_ssh_user=****  ansible_ssh_pass=*****
```
- Note : Please place the master-1 details in first row of [cluster]  group.This is used to identify the machine where ICP4D    installer has to be downloaded.

- In the [cluster] group first row are the details of master1/worker1:

    -   First column is the public IP.

    -   Second Column is the private IP.

    -   Third Column is name ex: worker1

    -   Fourth Column is type. Based on these columns whether the /data folder should be mounted decision is made.

    -   If type = master, only /ibm folder is mounted.

    -   If type = worker, both /ibm and /data folders are mounted.

    -   ansible_ssh_user and ansible_ssh_pass are the credentials to initiate SSH Connection. By default, connection port              is 22.

- In the [loadbalancer] group are the details of loadbalancer.

    -   First column is the public IP.

    -   Second Column is the private IP.

    -   Third Column is name ex: name = loadbalancer.

    -   Fourth Column is type. Ex: Proxy.

    -   ansible_ssh_user and ansible_ssh_pass are the credentials to initiate SSH Connection. By default, connection port is           22.

- Below is the sample hosts file for 6 node cluster with 1 loadbalancer.

```
[cluster]
***.**.**.**  private_ip=**.***.**.**    name=master1        type=master ansible_ssh_user=root ansible_ssh_pass=**********
***.**.**.**  private_ip=**.***.**.**    name=master2        type=master ansible_ssh_user=root ansible_ssh_pass=**********
***.**.**.**  private_ip=**.***.**.**    name=master3        type=master ansible_ssh_user=root ansible_ssh_pass=**********
***.**.**.**  private_ip=**.***.**.**    name=worker1        type=worker ansible_ssh_user=root ansible_ssh_pass=**********
***.**.**.**  private_ip=**.***.**.**    name=worker2        type=worker ansible_ssh_user=root ansible_ssh_pass=**********
***.**.**.**  private_ip=**.***.**.**    name=worker3        type=worker ansible_ssh_user=root ansible_ssh_pass=**********
[loadbalancer]
***.**.**.** private_ip=**.***.**.**     name=loadbalancer   type=proxy ansible_ssh_user=root ansible_ssh_pass=**********
```
- Note : Please place the master-1 details in first row of [cluster]  group.This is used to identify the machine where ICP4D    installer has to be downloaded.

- Navigate to vars folder and the external\_vars.yml is the file to specify configuration.

```
---
ntpserver: pool.ntp.org
ibmdiskdevicename: vdb
datadiskdevicename: vdc
icp4dtarurl: http://ibm-open-platform.ibm.com/repos/ICP4D/v1.2.1.1/GA/x86_64/EE/icp4d_ee_1.2.1.1_x86_64.tar
icp4dtarinstalldir: /ibm/icp4d.tar
icp4dtarunarchivedir: /ibm/
icp4dtaraddonurl: http://ibm-open-platform.ibm.com/repos/ICP4D/v1.2.1.0/GA/dv-ppa.tar
icp4daddoninstalldir: /ibm/modules/dv-ppa.tar

```

- Above are the default values used, can be configured as required.

   - ntpserver: Configure the time server to be used for synch machines.

   - ibmdiskdevicename: the device disk where ibm is mounted.

   - datadiskdevicename: Device disk where data is mounted.

   - icp4dtarurl: URL from where the ICP4D tar file is downloaded.

   - icp4dtarinstalldir: Directory where ICP4D tar files need to be downloaded on the machine.

   - icp4dtarunarchivedir: Directory where ICP4D tar files needs to be untar.

Once the hosts file is ready, then you can start the ICP4D automation.

```
 Command: ansible-playbook -i hosts masterplay.yml
 
 ```

    - i is the option specify inventory file (Here hosts is inventory file name i.e. sample hosts file as above)

    - masterplay.yml is the main playbook which automates below steps.

- Step1: Changes the root password for all machines. By default, password is set to icp4d@Admin.(changerootpwd.yml)

- Step2: Sync the clock for all machines. (clocksync.yml)

- Step3: Mounts the /ibm and /data disks. (icp4d\_disk.yml)

- Step4: Displays the directory list of every machine. (dircheck.yml)

- Step5: Install Haproxy, configure and enable it on loadbalancer.(installhaproxy.yml)

- Step6: Download the ICP4D tar file, untar it and make it executable.(installicp4durl.yml)

- Step7: Generate wdp config file on master-1 node. (generatewdpconf.yml)

- Step8: Run Preinstall validation Script. (preinstallvalidate.yml)

- Step9: Start the installer. (startinstaller.yml)

## Additional Info:
- To check whether selinux is in permissive mode,if not set to permissive mode.
```
Command:  ansible-playbook -i hosts playbooks/selinux.yml 
```
- Reboot to make selinux change effective
```
Command: ansible-playbook -i hosts playbooks/reboot.yml 
```

## Failure Check:
- If Automation fails at particular task,Ex: If it fails at task precheck-worker,then run the below command to start from that   particular task

```
command: ansible-playbook -i hosts masterplay.yml --start-at-task="precheck-worker"
```

## Curious to check what is happening on remote machine
```
ps -ef | grep ansible
strace -p <ProcessID>
```
